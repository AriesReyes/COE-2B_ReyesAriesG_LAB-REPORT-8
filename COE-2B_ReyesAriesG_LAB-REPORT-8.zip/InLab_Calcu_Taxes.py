
TAX_RATE = 0.25
STANDARD_DEDUCTION = 12400.0
DEPENDENT_DEDUCTION = 1100.0

grossIncome = float(input("Enter the gross income: "))
numDependents = int(input("Enter the number of dependents: "))

taxableIncome = grossIncome - STANDARD_DEDUCTION - \
 DEPENDENT_DEDUCTION * numDependents
incomeTax = taxableIncome * TAX_RATE

print("The income tax is $" + str(incomeTax))