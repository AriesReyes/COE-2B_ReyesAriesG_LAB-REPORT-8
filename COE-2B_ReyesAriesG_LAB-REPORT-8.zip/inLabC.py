from PyQt6 import uic
from PyQt6.Qtwidgets import QApplication

form, window = uic.loadUiType("qtdestry.ui")

app = QApplication([])
window = Window()
form = Form()
form.setupUi(window)
window.show()
app.exec()